
## ULX4M series

This hardware is licensed under CERN-OHL-S v2 or later.

Copyright (c)  2020 Intergalaktik d.o.o. <warp@intergalaktik.eu>

Licensed under CERN-OHL-S v2 or later (https://cern.ch/cern-ohl)
This work is provided by <Intergalaktik ltd> without warranties or conditions
of any kind, either express or implied, including without limitation any
warranties or conditions of title, non-infringement, merchantability, or
fitness for a particular purpose. You are solely responsible for
determining the appropriateness of using or redistributing this work and
assume any risks associated with your exercise of permissions under this
License.

This documentation is distributed WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY, INCLUDING OF MERCHANTABILITY, SATISFACTORY QUALITY AND
FITNESS FOR A PARTICULAR PURPOSE. Please see the CERN-OHL-S v2 for
applicable conditions.
  
Source Location: https://github.com/intergalaktik/ulx4m

This source describes Open Hardware and is licensed under the CERN-OHL-S v2
You may redistribute and modify this documentation and make products
using it under the terms of the CERN-OHL-S v2 or later (https:/cern.ch/cern-ohl).
This documentation is distributed WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY, INCLUDING OF MERCHANTABILITY, SATISFACTORY QUALITY
AND FITNESS FOR A PARTICULAR PURPOSE. Please see the CERN-OHL-S v2
for applicable conditions

[![License: CERN-OHL-S v2](https://img.shields.io/badge/License-CERN--OHL--S_v2-GREEN.svg)](https://opensource.org/CERN-OHL-S)
